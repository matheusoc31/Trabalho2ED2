#include "../headers/libraries.h"

//No_VP::No_VP()
//{
//    //ctor
//}

//No_VP::~No_VP()
//{
//    //dtor
//}
