#ifndef PATRICIATREE_H_INCLUDED
#define PATRICIATREE_H_INCLUDED

class PatriciaTree {

    NoPatricia raiz;
    int tamAlfabeto;

//    buscar;
//    inserir;
//    remover;

};

#endif // PATRICIATREE_H_INCLUDED
