#include "NoTST.h"

NoTST::NoTST()
{
    //ctor
}

NoTST::~NoTST()
{
    //dtor
}

NoTST*
