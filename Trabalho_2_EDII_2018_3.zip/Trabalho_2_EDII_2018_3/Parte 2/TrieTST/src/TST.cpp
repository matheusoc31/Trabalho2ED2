#include "TST.h"
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <sstream>

using namespace std;

TST::TST()
{
    raiz = NULL;
}

TST::~TST()
{
    //dtor
}

void TST::inserir(string palavra)
{
    raiz = auxI
}
