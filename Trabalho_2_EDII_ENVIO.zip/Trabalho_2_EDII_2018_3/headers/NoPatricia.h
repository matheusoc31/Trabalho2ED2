#ifndef NOPATRICIA_H_INCLUDED
#define NOPATRICIA_H_INCLUDED

class NoPatricia {

    NoPatricia filho*
    indChave = -1

};


#endif // NOPATRICIA_H_INCLUDED
