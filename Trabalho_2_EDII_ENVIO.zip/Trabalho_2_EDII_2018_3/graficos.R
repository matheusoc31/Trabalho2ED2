

N <- c(1000, 5000, 10000, 50000, 100000, 500000)
Nlabels <- c("1000", "5000", "10000", "50000", "100000", "500000")
tree_names <- c("AVL", "AVLM", "VP", "Splay", "B3", "B5")


#****************************************************************************
# Inserção

timeInsercaoAVL <- c(0.0053686, 0.0225684, 0.0472906, 0.281396, 0.633169, 2.52392)
compInsercaoAVL <- c(8727, 55396, 120941, 723574, 1548794, 5358834)
copiasInsercaoAVL <- c(11361, 68488, 147140, 854589, 1810625, 6144847)

timeInsercaoAVLM <- c(0.0064164, 0.0232746, 0.047403, 0.28717, 0.639901, 2.49402)
compInsercaoAVLM <- c(9133, 57778, 126267, 753895, 1613030, 5579210)
copiasInsercaoAVLM <- c(10740, 65899, 142672, 836557, 1781507, 6084405)

timeInsercaoVP <- c(0.001721, 0.007633, 0.0147144, 0.0855602, 0.200897, 0.74538)
compInsercaoVP <- c(30673, 194689, 424696, 2536266, 5422066, 18595921)
copiasInsercaoVP <- c(11804, 70886, 151930, 877011, 1849469, 6156584)

timeInsercaoSplay <- c(0.0028238, 0.0100614, 0.0210728, 0.127305, 0.298766, 1.18016)
compInsercaoSplay <- c(38453, 254824, 564160, 3449249, 7428814, 25547081)
copiasInsercaoSplay <- c(28098, 182138, 400542, 2420167, 5190593, 17681007)

timeInsercaoB3 <- c(0.0035576, 0.0199548, 0.0382108, 0.234147, 0.525787, 1.75511)
compInsercaoB3 <- c(10918, 69473, 152414, 909695, 1951666, 6747629)
copiasInsercaoB3 <- c(3788, 19055, 38137, 190806, 381564, 1140007)

timeInsercaoB5 <- c(0.0033084, 0.0146932, 0.0321196, 0.213448, 0.453389, 1.59864)
compInsercaoB5 <- c(12069, 77170, 167322, 1005498, 2153933, 7443286)
copiasInsercaoB5 <- c(5089, 25876, 51784, 258900, 517566, 1547852)

timeInsertion <- as.matrix(data.frame(rbind(timeInsercaoAVL, timeInsercaoAVLM, 
                                            timeInsercaoVP, timeInsercaoSplay, 
                                            timeInsercaoB3, timeInsercaoB5)))

compInsertion <- as.matrix(data.frame(rbind(compInsercaoAVL, compInsercaoAVLM, 
                                            compInsercaoVP, compInsercaoSplay, 
                                            compInsercaoB3, compInsercaoB5)))

copiasInsertion <- as.matrix(data.frame(rbind(copiasInsercaoAVL, copiasInsercaoAVLM, 
                                            copiasInsercaoVP, copiasInsercaoSplay, 
                                            copiasInsercaoB3, copiasInsercaoB5)))

colnames(timeInsertion) <- Nlabels
colnames(compInsertion) <- Nlabels
colnames(copiasInsertion) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeInsertion.pdf")
barplot(timeInsertion, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NInsercao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Inserção")
legend(x = 1, y = 2, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compInsertion.pdf")
barplot(compInsertion, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NInsercao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Inserção")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasInsertion.pdf")
barplot(copiasInsertion, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NInsercao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Inserção")
legend(x = 1, y = 10e06, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

#****************************************************************************
# Busca
# Ninsercao = 1000

timeBuscaAVL1000 <- c(0.0002926, 0.0013586, 0.0023852, 0.009625, 0.01848, 0.0913188)
compBuscaAVL1000 <- c(20392, 101927, 203854, 1019355, 2038275, 10191667)
copiasBuscaAVL1000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAAVL1000 <- c(0.0001854, 0.000589, 0.0011722, 0.0051206, 0.0105518, 0.0556998)
compBuscaORDENADAAVL1000 <- c(20401, 101918, 203853, 1019506, 2038370, 10191857)
copiasBuscaORDENADAAVL1000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaAVLM1000 <- c(0.0004176, 0.0014076, 0.0023922, 0.0098786, 0.0188524, 0.0879916)
compBuscaAVLM1000 <- c(21279, 106555, 213217, 1065817, 2130940, 10658683)
copiasBuscaAVLM1000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAAVLM1000 <- c(0.0001734, 0.0006198, 0.001149, 0.0053678, 0.0106504, 0.0554884)
compBuscaORDENADAAVLM1000 <- c(21287, 106495, 213170, 1066012, 2131131, 10658862)
copiasBuscaORDENADAAVLM1000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaVP1000 <- c(0.0003274, 0.0010048, 0.0019124, 0.0071914, 0.01468, 0.0674954)
compBuscaVP1000 <- c(20525, 102617, 205245, 1026039, 2051208, 10259088)
copiasBuscaVP1000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAVP1000 <- c(0.0001522, 0.0004258, 0.000753, 0.0032018, 0.0067432, 0.0365304)
compBuscaORDENADAVP1000 <- c(20531, 102555, 205344, 1026056, 2050864, 10258721)
copiasBuscaORDENADAVP1000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaSplay1000 <- c(0.0009704, 0.0028916, 0.0052074, 0.0243862, 0.0463498, 0.224807)
compBuscaSplay1000 <- c(36082, 179389, 358874, 1780798, 3559670, 17775750)
copiasBuscaSplay1000 <- c(24331, 120835, 241774, 1198716, 2395729, 11961799)

timeBuscaORDENADASplay1000 <- c(0.0001714, 0.0003896, 0.0006566, 0.0026156, 0.0048676, 0.027359)
compBuscaORDENADASplay1000 <- c(9460, 32633, 60234, 279990, 554495, 2751569)
copiasBuscaORDENADASplay1000 <- c(7159, 24235, 44325, 204076, 403650, 2001261)

timeBuscaB31000 <- c(0.000295, 0.00102, 0.0018438, 0.0063748, 0.0127094, 0.0617486)
compBuscaB31000 <- c(17962, 89748, 179400, 897282, 1795117, 8977769)
copiasBuscaB31000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAB31000 <- c(0.0001606, 0.0004498, 0.0007496, 0.0032248, 0.0061642, 0.0349624)
compBuscaORDENADAB31000 <- c(17980, 89844, 179488, 897207, 1795124, 8977602)
copiasBuscaORDENADAB31000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaB51000 <- c(0.0001722, 0.000677, 0.001441, 0.0053632, 0.0106312, 0.0505866)
compBuscaB51000 <- c(18168, 91158, 182025, 910026, 1818309, 9091835)
copiasBuscaB51000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAB51000 <- c(0.00012, 0.0003626, 0.000643, 0.0028966, 0.0061114, 0.0337994)
compBuscaORDENADAB51000 <- c(18213, 91257, 182165, 909830, 1818995, 9092151)
copiasBuscaORDENADAB51000 <- c(0, 0, 0, 0, 0, 0)

#-----------------------------
# Graficos busca

timeBusca1000 <- as.matrix(data.frame(rbind(timeBuscaAVL1000, timeBuscaAVLM1000, 
                                            timeBuscaVP1000, timeBuscaSplay1000, 
                                            timeBuscaB31000, timeBuscaB51000)))

compBusca1000 <- as.matrix(data.frame(rbind(compBuscaAVL1000, compBuscaAVLM1000, 
                                            compBuscaVP1000, compBuscaSplay1000, 
                                            compBuscaB31000, compBuscaB51000)))

copiasBusca1000 <- as.matrix(data.frame(rbind(copiasBuscaAVL1000, copiasBuscaAVLM1000, 
                                              copiasBuscaVP1000, copiasBuscaSplay1000, 
                                              copiasBuscaB31000, copiasBuscaB51000)))

colnames(timeBusca1000) <- Nlabels
colnames(compBusca1000) <- Nlabels
colnames(copiasBusca1000) <- Nlabels


pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeBusca1000.pdf")
barplot(timeBusca1000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Busca (NInserção = 1000)")
legend(x = 1, y = 2e-01, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compBusca1000.pdf")
barplot(compBusca1000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Busca (NInserção = 1000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasBusca1000.pdf")
barplot(copiasBusca1000['copiasBuscaSplay1000',], col=c("green"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Busca (NInserção = 1000)")
legend(x = 1, y = 5e06, legend = "Splay",
       fill = "green", bty = "n")
dev.off()


#-----------------------------
# Graficos busca ordenada

timeBuscaORDENADA1000 <- as.matrix(data.frame(rbind(timeBuscaORDENADAAVL1000, timeBuscaORDENADAAVLM1000, 
                                            timeBuscaORDENADAVP1000, timeBuscaORDENADASplay1000, 
                                            timeBuscaORDENADAB31000, timeBuscaORDENADAB51000)))

compBuscaORDENADA1000 <- as.matrix(data.frame(rbind(compBuscaORDENADAAVL1000, compBuscaORDENADAAVLM1000, 
                                            compBuscaORDENADAVP1000, compBuscaORDENADASplay1000, 
                                            compBuscaORDENADAB31000, compBuscaORDENADAB51000)))

copiasBuscaORDENADA1000 <- as.matrix(data.frame(rbind(copiasBuscaORDENADAAVL1000, copiasBuscaORDENADAAVLM1000, 
                                              copiasBuscaORDENADAVP1000, copiasBuscaORDENADASplay1000, 
                                              copiasBuscaORDENADAB31000, copiasBuscaORDENADAB51000)))

colnames(timeBuscaORDENADA1000) <- Nlabels
colnames(compBuscaORDENADA1000) <- Nlabels
colnames(copiasBuscaORDENADA1000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeBuscaORDENADA1000.pdf")
barplot(timeBuscaORDENADA1000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Busca Ordenada (NInserção = 1000)")
legend(x = 1, y = 6e-02, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compBuscaORDENADA1000.pdf")
barplot(compBuscaORDENADA1000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Busca Ordenada (NInserção = 1000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasBuscaORDENADA1000.pdf")
barplot(copiasBuscaORDENADA1000['copiasBuscaORDENADASplay1000',], col=c("green"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Busca Ordenada (NInserção = 1000)")
legend(x = 1, y = 1e06, legend = "Splay",
       fill = "green", bty = "n")
dev.off()

#****************************************************************************
# Busca
# Ninsercao = 5000

timeBuscaAVL5000 <- c(0.0004882, 0.0021392, 0.0032994, 0.014219, 0.0268294, 0.130429)
compBuscaAVL5000 <- c(25065, 125255, 250544, 1252739, 2505440, 12525392)
copiasBuscaAVL5000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAAVL5000 <- c(0.0003332, 0.001016, 0.0017098, 0.0065964, 0.0129902, 0.0643902)
compBuscaORDENADAAVL5000 <- c(25056, 125274, 250547, 1253034, 2505536, 12525314)
copiasBuscaORDENADAAVL5000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaAVLM5000 <- c(0.000458, 0.0019598, 0.0034664, 0.0138758, 0.0266536, 0.132177)
compBuscaAVLM5000 <- c(26242, 131180, 262146, 1311700, 2622338, 13119898)
copiasBuscaAVLM5000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAAVLM5000 <- c(0.0003446, 0.0010504, 0.0017578, 0.0069918, 0.0128334, 0.0671366)
compBuscaORDENADAAVLM5000 <- c(26293, 131092, 262070, 1311528, 2622612, 13119060)
copiasBuscaORDENADAAVLM5000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaVP5000 <- c(0.0003252, 0.0016876, 0.0027578, 0.012104, 0.022102, 0.10358)
compBuscaVP5000 <- c(25245, 126123, 252122, 1260711, 2521590, 12609886)
copiasBuscaVP5000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAVP5000 <- c(0.0002734, 0.0008276, 0.0013556, 0.00467, 0.0086422, 0.044478)
compBuscaORDENADAVP5000 <- c(25244, 126173, 252036, 1260725, 2521611, 12609473)
copiasBuscaORDENADAVP5000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaSplay5000 <- c(0.0008338, 0.0040476, 0.0075232, 0.0321936, 0.0625002, 0.305753)
compBuscaSplay5000 <- c(46982, 228055, 459910, 2257010, 4501174, 22421896)
copiasBuscaSplay5000 <- c(31438, 152015, 306698, 1503828, 2999379, 14936050)

timeBuscaORDENADASplay5000 <- c(0.0003118, 0.0007982, 0.0012386, 0.0030518, 0.0053882, 0.0281018)
compBuscaORDENADASplay5000 <- c(14328, 47652, 79027, 301524, 576342, 2773392)
copiasBuscaORDENADASplay5000 <- c(10601, 36012, 59557, 221804, 421650, 2019624)

timeBuscaB35000 <- c(0.0003436, 0.0016944, 0.0028258, 0.0112344, 0.0215044, 0.102291)
compBuscaB35000 <- c(22871, 114167, 228422, 1141632, 2283062, 11416041)
copiasBuscaB35000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAB35000 <- c(0.0002552, 0.0007946, 0.0012934, 0.004738, 0.0084132, 0.0433452)
compBuscaORDENADAB35000 <- c(22843, 114120, 228357, 1141305, 2282787, 11416685)
copiasBuscaORDENADAB35000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaB55000 <- c(0.0002024, 0.0011432, 0.0019722, 0.007774, 0.0150924, 0.072091)
compBuscaB55000 <- c(22606, 113512, 227247, 1135799, 2270704, 11355780)
copiasBuscaB55000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAB55000 <- c(0.0001898, 0.0005816, 0.0010444, 0.0038528, 0.0075524, 0.0399782)
compBuscaORDENADAB55000 <- c(22682, 113576, 227194, 1135459, 2270635, 11356162)
copiasBuscaORDENADAB55000 <- c(0, 0, 0, 0, 0, 0)

#-----------------------------
# Graficos busca

timeBusca5000 <- as.matrix(data.frame(rbind(timeBuscaAVL5000, timeBuscaAVLM5000, 
                                            timeBuscaVP5000, timeBuscaSplay5000, 
                                            timeBuscaB35000, timeBuscaB55000)))

compBusca5000 <- as.matrix(data.frame(rbind(compBuscaAVL5000, compBuscaAVLM5000, 
                                            compBuscaVP5000, compBuscaSplay5000, 
                                            compBuscaB35000, compBuscaB55000)))

copiasBusca5000 <- as.matrix(data.frame(rbind(copiasBuscaAVL5000, copiasBuscaAVLM5000, 
                                              copiasBuscaVP5000, copiasBuscaSplay5000, 
                                              copiasBuscaB35000, copiasBuscaB55000)))

colnames(timeBusca5000) <- Nlabels
colnames(compBusca5000) <- Nlabels
colnames(copiasBusca5000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeBusca5000.pdf")
barplot(timeBusca5000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Busca (NInserção = 5000)")
legend(x = 1, y = 2e-01, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compBusca5000.pdf")
barplot(compBusca5000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Busca (NInserção = 5000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasBusca5000.pdf")
barplot(copiasBusca5000['copiasBuscaSplay5000',], col=c("green"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Busca (NInserção = 5000)")
legend(x = 1, y = 5e06, legend = "Splay",
       fill = "green", bty = "n")
dev.off()


#-----------------------------
# Graficos busca ordenada

timeBuscaORDENADA5000 <- as.matrix(data.frame(rbind(timeBuscaORDENADAAVL5000, timeBuscaORDENADAAVLM5000, 
                                                    timeBuscaORDENADAVP5000, timeBuscaORDENADASplay5000, 
                                                    timeBuscaORDENADAB35000, timeBuscaORDENADAB55000)))

compBuscaORDENADA5000 <- as.matrix(data.frame(rbind(compBuscaORDENADAAVL5000, compBuscaORDENADAAVLM5000, 
                                                    compBuscaORDENADAVP5000, compBuscaORDENADASplay5000, 
                                                    compBuscaORDENADAB35000, compBuscaORDENADAB55000)))

copiasBuscaORDENADA5000 <- as.matrix(data.frame(rbind(copiasBuscaORDENADAAVL5000, copiasBuscaORDENADAAVLM5000, 
                                                      copiasBuscaORDENADAVP5000, copiasBuscaORDENADASplay5000, 
                                                      copiasBuscaORDENADAB35000, copiasBuscaORDENADAB55000)))

colnames(timeBuscaORDENADA5000) <- Nlabels
colnames(compBuscaORDENADA5000) <- Nlabels
colnames(copiasBuscaORDENADA5000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeBuscaORDENADA5000.pdf")
barplot(timeBuscaORDENADA5000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Busca Ordenada (NInserção = 5000)")
legend(x = 1, y = 6e-02, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compBuscaORDENADA5000.pdf")
barplot(compBuscaORDENADA5000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Busca Ordenada (NInserção = 5000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasBuscaORDENADA5000.pdf")
barplot(copiasBuscaORDENADA5000['copiasBuscaORDENADASplay5000',], col=c("green"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Busca Ordenada (NInserção = 5000)")
legend(x = 1, y = 1e06, legend = "Splay",
       fill = "green", bty = "n")
dev.off()


#****************************************************************************
# Busca
# Ninsercao = 10000

timeBuscaAVL10000 <- c(0.0004728, 0.0026176, 0.004045, 0.0165958, 0.0312072, 0.149149)
compBuscaAVL10000 <- c(27068, 135323, 270738, 1353603, 2707195, 13534094)
copiasBuscaAVL10000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAAVL10000 <- c(0.0004018, 0.0013256, 0.00216, 0.0077122, 0.0143276, 0.0685126)
compBuscaORDENADAAVL10000 <- c(27053, 135352, 270691, 1353754, 2707410, 13534685)
copiasBuscaORDENADAAVL10000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaAVLM10000 <- c(0.000419, 0.0024222, 0.004055, 0.0174326, 0.0316344, 0.152131)
compBuscaAVLM10000 <- c(28314, 141624, 283245, 1416113, 2830593, 14161450)
copiasBuscaAVLM10000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAAVLM10000 <- c(0.0004438, 0.0013818, 0.0022564, 0.0079454, 0.0149768, 0.0721214)
compBuscaORDENADAAVLM10000 <- c(28271, 141655, 283179, 1415803, 2831081, 14159441)
copiasBuscaORDENADAAVLM10000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaVP10000 <- c(0.000348, 0.0020994, 0.003306, 0.0140038, 0.0255116, 0.120892)
compBuscaVP10000 <- c(27351, 136394, 273147, 1364966, 2730499, 13652635)
copiasBuscaVP10000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAVP10000 <- c(0.0003448, 0.001107, 0.0017132, 0.0054768, 0.0102836, 0.0483236)
compBuscaORDENADAVP10000 <- c(27335, 136408, 273160, 1365061, 2730532, 13652175)
copiasBuscaORDENADAVP10000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaSplay10000 <- c(0.001125, 0.0047222, 0.0091572, 0.0363696, 0.0707662, 0.345486)
compBuscaSplay10000 <- c(51854, 251040, 503600, 2465197, 4921660, 24442637)
copiasBuscaSplay10000 <- c(34672, 167034, 334585, 1637138, 3270468, 16232634)

timeBuscaORDENADASplay10000 <- c(0.000373, 0.0012024, 0.0017086, 0.0041406, 0.0064326, 0.0291592)
compBuscaORDENADASplay10000 <- c(16190, 57904, 95780, 327456, 602758, 2797274)
copiasBuscaORDENADASplay10000 <- c(11800, 43471, 72374, 243200, 443501, 2039761)

timeBuscaB310000 <- c(0.0003604, 0.002168, 0.003399, 0.0139892, 0.025411, 0.12287)
compBuscaB310000 <- c(24234, 120827, 241694, 1209145, 2417191, 12086873)
copiasBuscaB310000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAB310000 <- c(0.000345, 0.0010522, 0.0016372, 0.005007, 0.0095384, 0.0456286)
compBuscaORDENADAB310000 <- c(24217, 120970, 241944, 1209128, 2416996, 12087434)
copiasBuscaORDENADAB310000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaB510000 <- c(0.0002554, 0.001457, 0.00231, 0.0085088, 0.0172134, 0.0808766)
compBuscaB510000 <- c(23785, 119068, 238002, 1190894, 2380891, 11901537)
copiasBuscaB510000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAB510000 <- c(0.0002242, 0.0007836, 0.0012832, 0.0044118, 0.0081922, 0.0412994)
compBuscaORDENADAB510000 <- c(23751, 118950, 238163, 1190644, 2380943, 11901785)
copiasBuscaORDENADAB510000 <- c(0, 0, 0, 0, 0, 0)

#-----------------------------
# Graficos busca

timeBusca10000 <- as.matrix(data.frame(rbind(timeBuscaAVL10000, timeBuscaAVLM10000, 
                                            timeBuscaVP10000, timeBuscaSplay10000, 
                                            timeBuscaB310000, timeBuscaB510000)))

compBusca10000 <- as.matrix(data.frame(rbind(compBuscaAVL10000, compBuscaAVLM10000, 
                                            compBuscaVP10000, compBuscaSplay10000, 
                                            compBuscaB310000, compBuscaB510000)))

copiasBusca10000 <- as.matrix(data.frame(rbind(copiasBuscaAVL10000, copiasBuscaAVLM10000, 
                                              copiasBuscaVP10000, copiasBuscaSplay10000, 
                                              copiasBuscaB310000, copiasBuscaB510000)))

colnames(timeBusca10000) <- Nlabels
colnames(compBusca10000) <- Nlabels
colnames(copiasBusca10000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeBusca10000.pdf")
barplot(timeBusca10000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Busca (NInserção = 10000)")
legend(x = 1, y = 2e-01, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compBusca10000.pdf")
barplot(compBusca10000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Busca (NInserção = 10000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasBusca10000.pdf")
barplot(copiasBusca10000['copiasBuscaSplay10000',], col=c("green"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Busca (NInserção = 10000)")
legend(x = 1, y = 5e06, legend = "Splay",
       fill = "green", bty = "n")
dev.off()


#-----------------------------
# Graficos busca ordenada

timeBuscaORDENADA10000 <- as.matrix(data.frame(rbind(timeBuscaORDENADAAVL10000, timeBuscaORDENADAAVLM10000, 
                                                    timeBuscaORDENADAVP10000, timeBuscaORDENADASplay10000, 
                                                    timeBuscaORDENADAB310000, timeBuscaORDENADAB510000)))

compBuscaORDENADA10000 <- as.matrix(data.frame(rbind(compBuscaORDENADAAVL10000, compBuscaORDENADAAVLM10000, 
                                                    compBuscaORDENADAVP10000, compBuscaORDENADASplay10000, 
                                                    compBuscaORDENADAB310000, compBuscaORDENADAB510000)))

copiasBuscaORDENADA10000 <- as.matrix(data.frame(rbind(copiasBuscaORDENADAAVL10000, copiasBuscaORDENADAAVLM10000, 
                                                      copiasBuscaORDENADAVP10000, copiasBuscaORDENADASplay10000, 
                                                      copiasBuscaORDENADAB310000, copiasBuscaORDENADAB510000)))

colnames(timeBuscaORDENADA10000) <- Nlabels
colnames(compBuscaORDENADA10000) <- Nlabels
colnames(copiasBuscaORDENADA10000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeBuscaORDENADA10000.pdf")
barplot(timeBuscaORDENADA10000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Busca Ordenada (NInserção = 10000)")
legend(x = 1, y = 6e-02, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compBuscaORDENADA10000.pdf")
barplot(compBuscaORDENADA10000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Busca Ordenada (NInserção = 10000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasBuscaORDENADA10000.pdf")
barplot(copiasBuscaORDENADA10000['copiasBuscaORDENADASplay10000',], col=c("green"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Busca Ordenada (NInserção = 10000)")
legend(x = 1, y = 1e06, legend = "Splay",
       fill = "green", bty = "n")
dev.off()



#****************************************************************************
# Busca
# Ninsercao = 50000

timeBuscaAVL50000 <- c(0.0008326, 0.0042684, 0.0076452, 0.0356904, 0.0684512, 0.329686)
compBuscaAVL50000 <- c(31812, 159060, 318057, 1590000, 3180555, 15900104)
copiasBuscaAVL50000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAAVL50000 <- c(0.0006568, 0.002378, 0.0040672, 0.014255, 0.024356, 0.0863012)
compBuscaORDENADAAVL50000 <- c(31852, 159051, 318046, 1589935, 3180508, 15899409)
copiasBuscaORDENADAAVL50000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaAVLM50000 <- c(0.0009278, 0.0045278, 0.008191, 0.0356658, 0.0700216, 0.33212)
compBuscaAVLM50000 <- c(33124, 165761, 331428, 1657090, 3314061, 16573228)
copiasBuscaAVLM50000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAAVLM50000 <- c(0.0006628, 0.0023262, 0.0042202, 0.0144324, 0.0248226, 0.0903602)
compBuscaORDENADAAVLM50000 <- c(33212, 165803, 331494, 1656878, 3314072, 16572931)
copiasBuscaORDENADAAVLM50000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaVP50000 <- c(0.0006766, 0.0033758, 0.0065698, 0.0302276, 0.058696, 0.275168)
compBuscaVP50000 <- c(31888, 159660, 318961, 1595318, 3191090, 15953106)
copiasBuscaVP50000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAVP50000 <- c(0.0005852, 0.0019648, 0.0033332, 0.0107114, 0.0176416, 0.0627268)
compBuscaORDENADAVP50000 <- c(31912, 159689, 319004, 1595243, 3190987, 15952432)
copiasBuscaORDENADAVP50000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaSplay50000 <- c(0.0016622, 0.0082628, 0.0140234, 0.0608492, 0.121512, 0.564902)
compBuscaSplay50000 <- c(64404, 306347, 609613, 2947017, 5927256, 29167256)
copiasBuscaSplay50000 <- c(42946, 203337, 403164, 1946278, 3916641, 19266724)

timeBuscaORDENADASplay50000 <- c(0.0005298, 0.0019296, 0.0031976, 0.0092962, 0.0130874, 0.0373822)
compBuscaORDENADASplay50000 <- c(19616, 80058, 141252, 475311, 786082, 2986467)
copiasBuscaORDENADASplay50000 <- c(13903, 58274, 104305, 359452, 592893, 2200272)

timeBuscaB350000 <- c(0.0006572, 0.0032484, 0.0056484, 0.022498, 0.0433662, 0.186468)
compBuscaB350000 <- c(28332, 141700, 283168, 1415897, 2831704, 14162237)
copiasBuscaB350000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAB350000 <- c(0.0004968, 0.0016754, 0.0027524, 0.008946, 0.015843, 0.0565158)
compBuscaORDENADAB350000 <- c(28374, 141892, 283160, 1415875, 2831407, 14162921)
copiasBuscaORDENADAB350000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaB550000 <- c(0.0004098, 0.0018442, 0.0034058, 0.0139772, 0.0268704, 0.118019)
compBuscaB550000 <- c(28149, 140923, 281689, 1408749, 2817354, 14089916)
copiasBuscaB550000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAB550000 <- c(0.0003678, 0.001191, 0.0019724, 0.006727, 0.0120962, 0.0517586)
compBuscaORDENADAB550000 <- c(28185, 141241, 281457, 1408643, 2816917, 14089638)
copiasBuscaORDENADAB550000 <- c(0, 0, 0, 0, 0, 0)

#-----------------------------
# Graficos busca

timeBusca50000 <- as.matrix(data.frame(rbind(timeBuscaAVL50000, timeBuscaAVLM50000, 
                                            timeBuscaVP50000, timeBuscaSplay50000, 
                                            timeBuscaB350000, timeBuscaB550000)))

compBusca50000 <- as.matrix(data.frame(rbind(compBuscaAVL50000, compBuscaAVLM50000, 
                                            compBuscaVP50000, compBuscaSplay50000, 
                                            compBuscaB350000, compBuscaB550000)))

copiasBusca50000 <- as.matrix(data.frame(rbind(copiasBuscaAVL50000, copiasBuscaAVLM50000, 
                                              copiasBuscaVP50000, copiasBuscaSplay50000, 
                                              copiasBuscaB350000, copiasBuscaB550000)))

colnames(timeBusca50000) <- Nlabels
colnames(compBusca50000) <- Nlabels
colnames(copiasBusca50000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeBusca50000.pdf")
barplot(timeBusca50000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Busca (NInserção = 50000)")
legend(x = 1, y = 2e-01, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compBusca50000.pdf")
barplot(compBusca50000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Busca (NInserção = 50000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasBusca50000.pdf")
barplot(copiasBusca50000['copiasBuscaSplay50000',], col=c("green"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Busca (NInserção = 50000)")
legend(x = 1, y = 5e06, legend = "Splay",
       fill = "green", bty = "n")
dev.off()


#-----------------------------
# Graficos busca ordenada

timeBuscaORDENADA50000 <- as.matrix(data.frame(rbind(timeBuscaORDENADAAVL50000, timeBuscaORDENADAAVLM50000, 
                                                    timeBuscaORDENADAVP50000, timeBuscaORDENADASplay50000, 
                                                    timeBuscaORDENADAB350000, timeBuscaORDENADAB550000)))

compBuscaORDENADA50000 <- as.matrix(data.frame(rbind(compBuscaORDENADAAVL50000, compBuscaORDENADAAVLM50000, 
                                                    compBuscaORDENADAVP50000, compBuscaORDENADASplay50000, 
                                                    compBuscaORDENADAB350000, compBuscaORDENADAB550000)))

copiasBuscaORDENADA50000 <- as.matrix(data.frame(rbind(copiasBuscaORDENADAAVL50000, copiasBuscaORDENADAAVLM50000, 
                                                      copiasBuscaORDENADAVP50000, copiasBuscaORDENADASplay50000, 
                                                      copiasBuscaORDENADAB350000, copiasBuscaORDENADAB550000)))

colnames(timeBuscaORDENADA50000) <- Nlabels
colnames(compBuscaORDENADA50000) <- Nlabels
colnames(copiasBuscaORDENADA50000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeBuscaORDENADA50000.pdf")
barplot(timeBuscaORDENADA50000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Busca Ordenada (NInserção = 50000)")
legend(x = 1, y = 6e-02, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compBuscaORDENADA50000.pdf")
barplot(compBuscaORDENADA50000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Busca Ordenada (NInserção = 50000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasBuscaORDENADA50000.pdf")
barplot(copiasBuscaORDENADA50000['copiasBuscaORDENADASplay50000',], col=c("green"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Busca Ordenada (NInserção = 50000)")
legend(x = 1, y = 1e06, legend = "Splay",
       fill = "green", bty = "n")
dev.off()



#****************************************************************************
# Busca
# Ninsercao = 100000

timeBuscaAVL100000 <- c(0.000962, 0.0052156, 0.0097592, 0.0453898, 0.089104, 0.441902)
compBuscaAVL100000 <- c(33770, 168756, 337473, 1688324, 3375633, 16878644)
copiasBuscaAVL100000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAAVL100000 <- c(0.0008434, 0.0029244, 0.0054008, 0.018202, 0.0307122, 0.102746)
compBuscaORDENADAAVL100000 <- c(33745, 168718, 337421, 1688186, 3375269, 16878546)
copiasBuscaORDENADAAVL100000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaAVLM100000 <- c(0.0009496, 0.0052746, 0.0098568, 0.0463898, 0.0903448, 0.445404)
compBuscaAVLM100000 <- c(35182, 175776, 352315, 1760088, 3519763, 17600983)
copiasBuscaAVLM100000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAAVLM100000 <- c(0.000793, 0.0029142, 0.0053964, 0.018784, 0.0317354, 0.103925)
compBuscaORDENADAAVLM100000 <- c(35196, 175631, 351993, 1760004, 3519447, 17600028)
copiasBuscaORDENADAAVLM100000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaVP100000 <- c(0.0008702, 0.0047316, 0.008779, 0.0390884, 0.0782106, 0.373354)
compBuscaVP100000 <- c(33937, 169636, 339078, 1695686, 3390883, 16951952)
copiasBuscaVP100000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAVP100000 <- c(0.0007394, 0.0025308, 0.0045214, 0.014486, 0.0235396, 0.073636)
compBuscaORDENADAVP100000 <- c(33952, 169643, 339075, 1695366, 3390761, 16951128)
copiasBuscaORDENADAVP100000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaSplay100000 <- c(0.0019252, 0.0096546, 0.017653, 0.0804722, 0.162696, 0.756144)
compBuscaSplay100000 <- c(69072, 331149, 658015, 3159388, 6361640, 31198045)
copiasBuscaSplay100000 <- c(46038, 219638, 434861, 2084060, 4193444, 20567224)

timeBuscaORDENADASplay100000 <- c(0.0006418, 0.002386, 0.0042102, 0.0133132, 0.020056, 0.047672)
compBuscaORDENADASplay100000 <- c(20835, 87866, 157854, 571387, 942410, 3212664)
copiasBuscaORDENADASplay100000 <- c(14614, 63190, 114959, 429083, 713085, 2392735)

timeBuscaB3100000 <- c(0.0006978, 0.003588, 0.0065404, 0.0314138, 0.0622746, 0.279816)
compBuscaB3100000 <- c(30521, 153123, 306222, 1530000, 3060032, 15301689)
copiasBuscaB3100000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAB3100000 <- c(0.0006442, 0.0021684, 0.0038206, 0.0122968, 0.021019, 0.067121)
compBuscaORDENADAB3100000 <- c(30528, 153334, 306314, 1530077, 3059838, 15302183)
copiasBuscaORDENADAB3100000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaB5100000 <- c(0.0004994, 0.0022038, 0.0039202, 0.0178, 0.033588, 0.144649)
compBuscaB5100000 <- c(30266, 151027, 302513, 1508438, 3017619, 15093722)
copiasBuscaB5100000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAB5100000 <- c(0.0004594, 0.0015026, 0.0025186, 0.0085272, 0.0150938, 0.0574186)
compBuscaORDENADAB5100000 <- c(30366, 151053, 302457, 1507905, 3018694, 15093015)
copiasBuscaORDENADAB5100000 <- c(0, 0, 0, 0, 0, 0)

#-----------------------------
# Graficos busca

timeBusca100000 <- as.matrix(data.frame(rbind(timeBuscaAVL100000, timeBuscaAVLM100000, 
                                            timeBuscaVP100000, timeBuscaSplay100000, 
                                            timeBuscaB3100000, timeBuscaB5100000)))

compBusca100000 <- as.matrix(data.frame(rbind(compBuscaAVL100000, compBuscaAVLM100000, 
                                            compBuscaVP100000, compBuscaSplay100000, 
                                            compBuscaB3100000, compBuscaB5100000)))

copiasBusca100000 <- as.matrix(data.frame(rbind(copiasBuscaAVL100000, copiasBuscaAVLM100000, 
                                              copiasBuscaVP100000, copiasBuscaSplay100000, 
                                              copiasBuscaB3100000, copiasBuscaB5100000)))

colnames(timeBusca100000) <- Nlabels
colnames(compBusca100000) <- Nlabels
colnames(copiasBusca100000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeBusca100000.pdf")
barplot(timeBusca100000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Busca (NInserção = 100000)")
legend(x = 1, y = 2e-01, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compBusca100000.pdf")
barplot(compBusca100000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Busca (NInserção = 100000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasBusca100000.pdf")
barplot(copiasBusca100000['copiasBuscaSplay100000',], col=c("green"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Busca (NInserção = 100000)")
legend(x = 1, y = 5e06, legend = "Splay",
       fill = "green", bty = "n")
dev.off()


#-----------------------------
# Graficos busca ordenada

timeBuscaORDENADA100000 <- as.matrix(data.frame(rbind(timeBuscaORDENADAAVL100000, timeBuscaORDENADAAVLM100000, 
                                                    timeBuscaORDENADAVP100000, timeBuscaORDENADASplay100000, 
                                                    timeBuscaORDENADAB3100000, timeBuscaORDENADAB5100000)))

compBuscaORDENADA100000 <- as.matrix(data.frame(rbind(compBuscaORDENADAAVL100000, compBuscaORDENADAAVLM100000, 
                                                    compBuscaORDENADAVP100000, compBuscaORDENADASplay100000, 
                                                    compBuscaORDENADAB3100000, compBuscaORDENADAB5100000)))

copiasBuscaORDENADA100000 <- as.matrix(data.frame(rbind(copiasBuscaORDENADAAVL100000, copiasBuscaORDENADAAVLM100000, 
                                                      copiasBuscaORDENADAVP100000, copiasBuscaORDENADASplay100000, 
                                                      copiasBuscaORDENADAB3100000, copiasBuscaORDENADAB5100000)))

colnames(timeBuscaORDENADA100000) <- Nlabels
colnames(compBuscaORDENADA100000) <- Nlabels
colnames(copiasBuscaORDENADA100000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeBuscaORDENADA100000.pdf")
barplot(timeBuscaORDENADA100000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Busca Ordenada (NInserção = 100000)")
legend(x = 1, y = 6e-02, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compBuscaORDENADA100000.pdf")
barplot(compBuscaORDENADA100000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Busca Ordenada (NInserção = 100000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasBuscaORDENADA100000.pdf")
barplot(copiasBuscaORDENADA100000['copiasBuscaORDENADASplay100000',], col=c("green"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Busca Ordenada (NInserção = 100000)")
legend(x = 1, y = 1e06, legend = "Splay",
       fill = "green", bty = "n")
dev.off()


#****************************************************************************
# Busca
# Ninsercao = 500000

timeBuscaAVL500000 <- c(0.0008728, 0.004991, 0.0091942, 0.0419724, 0.0839444, 0.410596)
compBuscaAVL500000 <- c(22920, 114472, 228978, 1145051, 2290060, 11450410)
copiasBuscaAVL500000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAAVL500000 <- c(0.0007518, 0.0030274, 0.0052696, 0.0183966, 0.0314274, 0.0999232)
compBuscaORDENADAAVL500000 <- c(22923, 114447, 229110, 1144988, 2290070, 11450110)
copiasBuscaORDENADAAVL500000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaAVLM500000 <- c(0.0008384, 0.0048756, 0.008869, 0.0410772, 0.081536, 0.406425)
compBuscaAVLM500000 <- c(23673, 118767, 237891, 1188962, 2378652, 11891422)
copiasBuscaAVLM500000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAAVLM500000 <- c(0.0007296, 0.0030026, 0.0052984, 0.0186952, 0.0315878, 0.100631)
compBuscaORDENADAAVLM500000 <- c(23660, 118804, 237919, 1188806, 2378276, 11890977)
copiasBuscaORDENADAAVLM500000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaVP500000 <- c(0.0008012, 0.0043918, 0.0073742, 0.0361786, 0.0705206, 0.349471)
compBuscaVP500000 <- c(22892, 114278, 228397, 1142704, 2285610, 11428744)
copiasBuscaVP500000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAVP500000 <- c(0.0006912, 0.0026838, 0.0047076, 0.0154678, 0.024734, 0.0777644)
compBuscaORDENADAVP500000 <- c(22919, 114286, 228374, 1142866, 2285690, 11429431)
copiasBuscaORDENADAVP500000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaSplay500000 <- c(0.0016638, 0.0083194, 0.0155024, 0.0716686, 0.143368, 0.677439)
compBuscaSplay500000 <- c(47939, 231089, 458309, 2196344, 4395193, 21384427)
copiasBuscaSplay500000 <- c(31878, 153019, 302665, 1446736, 2887928, 14040044)

timeBuscaORDENADASplay500000 <- c(0.0005324, 0.001993, 0.0035166, 0.012814, 0.021787, 0.060526)
compBuscaORDENADASplay500000 <- c(13368, 57517, 107131, 443095, 785486, 2639545)
copiasBuscaORDENADASplay500000 <- c(9195, 40391, 75992, 322832, 580358, 2012183)

timeBuscaB3500000 <- c(0.0006348, 0.0034782, 0.0064974, 0.0301464, 0.0600868, 0.292796)
compBuscaB3500000 <- c(20492, 102842, 205595, 1027408, 2056298, 10279092)
copiasBuscaB3500000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAB3500000 <- c(0.0005698, 0.0021028, 0.0037714, 0.0128954, 0.0219924, 0.0648992)
compBuscaORDENADAB3500000 <- c(20472, 102764, 205549, 1027583, 2056408, 10278565)
copiasBuscaORDENADAB3500000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaB5500000 <- c(0.0004352, 0.002365, 0.0042984, 0.0187472, 0.0353664, 0.17173)
compBuscaB5500000 <- c(20479, 103061, 206156, 1029784, 2061971, 10304430)
copiasBuscaB5500000 <- c(0, 0, 0, 0, 0, 0)

timeBuscaORDENADAB5500000 <- c(0.000405, 0.0014656, 0.0026738, 0.009431, 0.0158008, 0.0504038)
compBuscaORDENADAB5500000 <- c(20468, 103111, 206161, 1029690, 2061705, 10303778)
copiasBuscaORDENADAB5500000 <- c(0, 0, 0, 0, 0, 0)

#-----------------------------
# Graficos busca

timeBusca500000 <- as.matrix(data.frame(rbind(timeBuscaAVL500000, timeBuscaAVLM500000, 
                                            timeBuscaVP500000, timeBuscaSplay500000, 
                                            timeBuscaB3500000, timeBuscaB5500000)))

compBusca500000 <- as.matrix(data.frame(rbind(compBuscaAVL500000, compBuscaAVLM500000, 
                                            compBuscaVP500000, compBuscaSplay500000, 
                                            compBuscaB3500000, compBuscaB5500000)))

copiasBusca500000 <- as.matrix(data.frame(rbind(copiasBuscaAVL500000, copiasBuscaAVLM500000, 
                                              copiasBuscaVP500000, copiasBuscaSplay500000, 
                                              copiasBuscaB3500000, copiasBuscaB5500000)))

colnames(timeBusca500000) <- Nlabels
colnames(compBusca500000) <- Nlabels
colnames(copiasBusca500000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeBusca500000.pdf")
barplot(timeBusca500000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Busca (NInserção = 500000)")
legend(x = 1, y = 2e-01, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compBusca500000.pdf")
barplot(compBusca500000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Busca (NInserção = 500000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasBusca500000.pdf")
barplot(copiasBusca500000['copiasBuscaSplay500000',], col=c("green"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Busca (NInserção = 500000)")
legend(x = 1, y = 5e06, legend = "Splay",
       fill = "green", bty = "n")
dev.off()


#-----------------------------
# Graficos busca ordenada

timeBuscaORDENADA500000 <- as.matrix(data.frame(rbind(timeBuscaORDENADAAVL500000, timeBuscaORDENADAAVLM500000, 
                                                    timeBuscaORDENADAVP500000, timeBuscaORDENADASplay500000, 
                                                    timeBuscaORDENADAB3500000, timeBuscaORDENADAB5500000)))

compBuscaORDENADA500000 <- as.matrix(data.frame(rbind(compBuscaORDENADAAVL500000, compBuscaORDENADAAVLM500000, 
                                                    compBuscaORDENADAVP500000, compBuscaORDENADASplay500000, 
                                                    compBuscaORDENADAB3500000, compBuscaORDENADAB5500000)))

copiasBuscaORDENADA500000 <- as.matrix(data.frame(rbind(copiasBuscaORDENADAAVL500000, copiasBuscaORDENADAAVLM500000, 
                                                      copiasBuscaORDENADAVP500000, copiasBuscaORDENADASplay500000, 
                                                      copiasBuscaORDENADAB3500000, copiasBuscaORDENADAB5500000)))

colnames(timeBuscaORDENADA500000) <- Nlabels
colnames(compBuscaORDENADA500000) <- Nlabels
colnames(copiasBuscaORDENADA500000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeBuscaORDENADA500000.pdf")
barplot(timeBuscaORDENADA500000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Busca Ordenada (NInserção = 500000)")
legend(x = 1, y = 6e-02, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compBuscaORDENADA500000.pdf")
barplot(compBuscaORDENADA500000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Busca Ordenada (NInserção = 500000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasBuscaORDENADA500000.pdf")
barplot(copiasBuscaORDENADA500000['copiasBuscaORDENADASplay500000',], col=c("green"), 
        border="white", font.axis=2, beside=T, xlab="NBusca", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Busca Ordenada (NInserção = 500000)")
legend(x = 1, y = 1e06, legend = "Splay",
       fill = "green", bty = "n")
dev.off()


#****************************************************************************
#****************************************************************************
# Remocao
# Ninsercao = 1000

timeRemocaoAVL1000 = c(0.0008846, 0.004012, 0.0081204, 0.0381194, 0.0800938, 0.394473)
compRemocaoAVL1000 = c(15326.2, 86263.8, 182599, 915353, 1.92864e+06, 9.73026e+06)
copiasRemocaoAVL1000 = c(11191.6, 65732.4, 141422, 708257, 1.51258e+06, 7.52116e+06)

timeRemocaoORDENADAAVL1000 = c(0.0006648, 0.0031182, 0.0065942, 0.028954, 0.0620886, 0.309343)
compRemocaoORDENADAAVL1000 = c(16264.8, 86491.2, 182867, 918120, 1.93339e+06, 9.82654e+06)
copiasRemocaoORDENADAAVL1000 = c(12168.6, 65949, 141607, 710050, 1.5151e+06, 7.53294e+06)

timeRemocaoAVLM1000 = c(0.000934, 0.0039272, 0.0074924, 0.0350752, 0.0649436, 0.319835)
compRemocaoAVLM1000 = c(16138.6, 84712.8, 172947, 872207, 1.68665e+06, 8.4907e+06)
copiasRemocaoAVLM1000 = c(11850.2, 65143.4, 133668, 673052, 1.29622e+06, 6.50607e+06)

timeRemocaoORDENADAAVLM1000 = c(0.0006516, 0.002958, 0.005582, 0.0258922, 0.0499666, 0.256545)
compRemocaoORDENADAAVLM1000 = c(16539, 86868.2, 170678, 844836, 1.6811e+06, 8.38873e+06)
copiasRemocaoORDENADAAVLM1000 = c(12555.8, 67543.8, 132384, 644838, 1.29554e+06, 6.43513e+06)

timeRemocaoVP1000 = c(0.000248, 0.00114, 0.0018802, 0.0073376, 0.0135238, 0.0664508)
compRemocaoVP1000 = c(15388.4, 77133.6, 154047, 769553, 1.53763e+06, 7.60589e+06)
copiasRemocaoVP1000 = c(0.2, 5.2, 10, 48, 65.4, 422.4)

timeRemocaoORDENADAVP1000 = c(0.0001438, 0.0004374, 0.0007876, 0.0033722, 0.0070286, 0.0376428)
compRemocaoORDENADAVP1000 = c(15366, 77106.4, 154006, 769182, 1.53682e+06, 7.60576e+06)
copiasRemocaoORDENADAVP1000 = c(0.2, 3.2, 6, 37.4, 41.4, 295.4)

timeRemocaoSplay1000 = c(0.0005224, 0.002617, 0.0056502, 0.0249084, 0.0483874, 0.225845)
compRemocaoSplay1000 = c(37098.2, 183236, 364842, 1.82261e+06, 3.64166e+06, 1.80063e+07)
copiasRemocaoSplay1000 = c(24337.4, 120103, 238838, 1.19316e+06, 2.38378e+06, 1.17885e+07)

timeRemocaoORDENADASplay1000 = c(0.000202, 0.000447, 0.0006634, 0.0027598, 0.005688, 0.0303748)
compRemocaoORDENADASplay1000 = c(11193.6, 37958.2, 70404.4, 330127, 654843, 3.25255e+06)
copiasRemocaoORDENADASplay1000 = c(7730.2, 24491.4, 44420.4, 204159, 403902, 2.00196e+06)

timeRemocaoB31000 = c(0.0004142, 0.0014842, 0.0025552, 0.0103716, 0.0215928, 0.100699)
compRemocaoB31000 = c(17980.6, 89580, 179200, 895838, 1.79158e+06, 8.92791e+06)
copiasRemocaoB31000 = c(1088.6, 3060.4, 5455.4, 30060.2, 78881.8, 357198)

timeRemocaoORDENADAB31000 = c(0.0002048, 0.0006714, 0.001035, 0.0043098, 0.0086544, 0.046386)
compRemocaoORDENADAB31000 = c(18680, 93419.2, 186960, 934421, 1.86841e+06, 9.31871e+06)
copiasRemocaoORDENADAB31000 = c(342.8, 392.4, 402.4, 427.8, 453.8, 730.6)

timeRemocaoB51000 = c(0.000295, 0.0012838, 0.0021966, 0.011503, 0.0188548, 0.083115)
compRemocaoB51000 = c(18699, 92856, 187477, 934390, 1.86218e+06, 9.15435e+06)
copiasRemocaoB51000 = c(1043.2, 4024.8, 7740.2, 69667.2, 82483.8, 341275)

timeRemocaoORDENADAB51000 = c(0.000152, 0.0004906, 0.0008732, 0.0039182, 0.0079808, 0.0441262)
compRemocaoORDENADAB51000 = c(18997.2, 94260.8, 189395, 944254, 1.88742e+06, 9.34454e+06)
copiasRemocaoORDENADAB51000 = c(193.6, 205.8, 206.2, 259.8, 279.4, 771)

#-----------------------------
# Graficos remocao

timeRemocao1000 <- as.matrix(data.frame(rbind(timeRemocaoAVL1000, timeRemocaoAVLM1000, 
                                            timeRemocaoVP1000, timeRemocaoSplay1000, 
                                            timeRemocaoB31000, timeRemocaoB51000)))

compRemocao1000 <- as.matrix(data.frame(rbind(compRemocaoAVL1000, compRemocaoAVLM1000, 
                                            compRemocaoVP1000, compRemocaoSplay1000, 
                                            compRemocaoB31000, compRemocaoB51000)))

copiasRemocao1000 <- as.matrix(data.frame(rbind(copiasRemocaoAVL1000, copiasRemocaoAVLM1000, 
                                              copiasRemocaoVP1000, copiasRemocaoSplay1000, 
                                              copiasRemocaoB31000, copiasRemocaoB51000)))

colnames(timeRemocao1000) <- Nlabels
colnames(compRemocao1000) <- Nlabels
colnames(copiasRemocao1000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeRemocao1000.pdf")
barplot(timeRemocao1000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Remoção (NInserção = 1000)")
legend(x = 1, y = 2e-01, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compRemocao1000.pdf")
barplot(compRemocao1000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Remoção (NInserção = 1000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasRemocao1000.pdf")
barplot(copiasRemocao1000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Remoção (NInserção = 1000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()


#-----------------------------
# Graficos remocao ordenada

timeRemocaoORDENADA1000 <- as.matrix(data.frame(rbind(timeRemocaoORDENADAAVL1000, timeRemocaoORDENADAAVLM1000, 
                                                    timeRemocaoORDENADAVP1000, timeRemocaoORDENADASplay1000, 
                                                    timeRemocaoORDENADAB31000, timeRemocaoORDENADAB51000)))

compRemocaoORDENADA1000 <- as.matrix(data.frame(rbind(compRemocaoORDENADAAVL1000, compRemocaoORDENADAAVLM1000, 
                                                    compRemocaoORDENADAVP1000, compRemocaoORDENADASplay1000, 
                                                    compRemocaoORDENADAB31000, compRemocaoORDENADAB51000)))

copiasRemocaoORDENADA1000 <- as.matrix(data.frame(rbind(copiasRemocaoORDENADAAVL1000, copiasRemocaoORDENADAAVLM1000, 
                                                      copiasRemocaoORDENADAVP1000, copiasRemocaoORDENADASplay1000, 
                                                      copiasRemocaoORDENADAB31000, copiasRemocaoORDENADAB51000)))

colnames(timeRemocaoORDENADA1000) <- Nlabels
colnames(compRemocaoORDENADA1000) <- Nlabels
colnames(copiasRemocaoORDENADA1000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeRemocaoORDENADA1000.pdf")
barplot(timeRemocaoORDENADA1000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Remoção Ordenada (NInserção = 1000)")
legend(x = 1, y = 2e-1, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compRemocaoORDENADA1000.pdf")
barplot(compRemocaoORDENADA1000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Remoção Ordenada (NInserção = 1000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasRemocaoORDENADA1000.pdf")
barplot(copiasRemocaoORDENADA1000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Remoção Ordenada (NInserção = 1000)")
legend(x = 1, y = 4e06, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()



#****************************************************************************
# Remocao
# Ninsercao = 5000

timeRemocaoAVL5000 = c(0.001311, 0.0061488, 0.0127364, 0.0541226, 0.11724, 0.57836)
compRemocaoAVL5000 = c(18892.2, 103771, 217460, 1.09033e+06, 2.28143e+06, 1.15024e+07)
copiasRemocaoAVL5000 = c(13536.6, 77479.4, 164893, 826046, 1.74535e+06, 8.68909e+06)

timeRemocaoORDENADAAVL5000 = c(0.0010106, 0.004237, 0.0087666, 0.0365676, 0.0774114, 0.366948)
compRemocaoORDENADAAVL5000 = c(19768.6, 104030, 217625, 1.09292e+06, 2.28704e+06, 1.15961e+07)
copiasRemocaoORDENADAAVL5000 = c(14514.6, 77752, 165138, 827653, 1.74842e+06, 8.6993e+06)

timeRemocaoAVLM5000 = c(0.0012082, 0.0058178, 0.010315, 0.0470422, 0.0865122, 0.441249)
compRemocaoAVLM5000 = c(19702.6, 103194, 209891, 1.05619e+06, 2.03737e+06, 1.03719e+07)
copiasRemocaoAVLM5000 = c(14226.6, 78050.2, 159239, 809962, 1.52582e+06, 7.82448e+06)

timeRemocaoORDENADAAVLM5000 = c(0.0009824, 0.0038986, 0.0070748, 0.032731, 0.0631504, 0.313711)
compRemocaoORDENADAAVLM5000 = c(20173, 105176, 207020, 1.02874e+06, 2.03636e+06, 1.01825e+07)
copiasRemocaoORDENADAAVLM5000 = c(14958.2, 79416.6, 155972, 777688, 1.5237e+06, 7.64632e+06)

timeRemocaoVP5000 = c(0.000313, 0.0015512, 0.0026548, 0.0109174, 0.0215588, 0.100656)
compRemocaoVP5000 = c(18862.8, 94391.2, 188586, 942095, 1.88253e+06, 9.32955e+06)
copiasRemocaoVP5000 = c(6.2, 26.4, 42.2, 193.6, 409.6, 2087.4)

timeRemocaoORDENADAVP5000 = c(0.000291, 0.0008504, 0.0013514, 0.004671, 0.0089934, 0.044788)
compRemocaoORDENADAVP5000 = c(18845.4, 94514.2, 188506, 941920, 1.88263e+06, 9.32285e+06)
copiasRemocaoORDENADAVP5000 = c(5.8, 16.8, 30.6, 130, 275.2, 1448.6)

timeRemocaoSplay5000 = c(0.000822, 0.0038872, 0.0072074, 0.0322946, 0.0626002, 0.305113)
compRemocaoSplay5000 = c(47941.6, 232250, 460690, 2.29168e+06, 4.57584e+06, 2.26822e+07)
copiasRemocaoSplay5000 = c(31408, 151686, 300353, 1.49349e+06, 2.98106e+06, 1.47788e+07)

timeRemocaoORDENADASplay5000 = c(0.0004232, 0.000992, 0.001309, 0.0033894, 0.0062164, 0.0313552)
compRemocaoORDENADASplay5000 = c(19345.4, 56459, 91553, 352421, 677253, 3.27591e+06)
copiasRemocaoORDENADASplay5000 = c(13513.6, 39024, 61571, 222515, 422220, 2.02109e+06)

timeRemocaoB35000 = c(0.0008028, 0.0030146, 0.0048166, 0.0166158, 0.0330058, 0.161688)
compRemocaoB35000 = c(22253.2, 110196, 220140, 1.09136e+06, 2.18058e+06, 1.08741e+07)
copiasRemocaoB35000 = c(2552.6, 8590.6, 14536.4, 43951.6, 99001.2, 624713)

timeRemocaoORDENADAB35000 = c(0.0005798, 0.0013416, 0.0019232, 0.0063266, 0.0114228, 0.056591)
compRemocaoORDENADAB35000 = c(23135, 116315, 232597, 1.16261e+06, 2.32521e+06, 1.16065e+07)
copiasRemocaoORDENADAB35000 = c(1095.8, 1756.4, 1926, 2173.8, 2289.4, 3641)

timeRemocaoB55000 = c(0.0004428, 0.0018568, 0.0029614, 0.0112626, 0.0216072, 0.113955)
compRemocaoB55000 = c(23182.4, 115073, 231352, 1.15326e+06, 2.30136e+06, 1.13492e+07)
copiasRemocaoB55000 = c(1250, 5493.2, 5865.2, 24249.4, 43545.6, 392838)

timeRemocaoORDENADAB55000 = c(0.0003492, 0.0009134, 0.001434, 0.0057246, 0.010916, 0.0528584)
compRemocaoORDENADAB55000 = c(23279, 116607, 233911, 1.16659e+06, 2.33169e+06, 1.15719e+07)
copiasRemocaoORDENADAB55000 = c(640, 983.4, 1058.6, 1255, 1525.4, 3666.2)

#-----------------------------
# Graficos remocao

timeRemocao5000 <- as.matrix(data.frame(rbind(timeRemocaoAVL5000, timeRemocaoAVLM5000, 
                                              timeRemocaoVP5000, timeRemocaoSplay5000, 
                                              timeRemocaoB35000, timeRemocaoB55000)))

compRemocao5000 <- as.matrix(data.frame(rbind(compRemocaoAVL5000, compRemocaoAVLM5000, 
                                              compRemocaoVP5000, compRemocaoSplay5000, 
                                              compRemocaoB35000, compRemocaoB55000)))

copiasRemocao5000 <- as.matrix(data.frame(rbind(copiasRemocaoAVL5000, copiasRemocaoAVLM5000, 
                                                copiasRemocaoVP5000, copiasRemocaoSplay5000, 
                                                copiasRemocaoB35000, copiasRemocaoB55000)))

colnames(timeRemocao5000) <- Nlabels
colnames(compRemocao5000) <- Nlabels
colnames(copiasRemocao5000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeRemocao5000.pdf")
barplot(timeRemocao5000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Remoção (NInserção = 5000)")
legend(x = 1, y = 5e-01, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compRemocao5000.pdf")
barplot(compRemocao5000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Remoção (NInserção = 5000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasRemocao5000.pdf")
barplot(copiasRemocao5000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Remoção (NInserção = 5000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()


#-----------------------------
# Graficos remocao ordenada

timeRemocaoORDENADA5000 <- as.matrix(data.frame(rbind(timeRemocaoORDENADAAVL5000, timeRemocaoORDENADAAVLM5000, 
                                                      timeRemocaoORDENADAVP5000, timeRemocaoORDENADASplay5000, 
                                                      timeRemocaoORDENADAB35000, timeRemocaoORDENADAB55000)))

compRemocaoORDENADA5000 <- as.matrix(data.frame(rbind(compRemocaoORDENADAAVL5000, compRemocaoORDENADAAVLM5000, 
                                                      compRemocaoORDENADAVP5000, compRemocaoORDENADASplay5000, 
                                                      compRemocaoORDENADAB35000, compRemocaoORDENADAB55000)))

copiasRemocaoORDENADA5000 <- as.matrix(data.frame(rbind(copiasRemocaoORDENADAAVL5000, copiasRemocaoORDENADAAVLM5000, 
                                                        copiasRemocaoORDENADAVP5000, copiasRemocaoORDENADASplay5000, 
                                                        copiasRemocaoORDENADAB35000, copiasRemocaoORDENADAB55000)))

colnames(timeRemocaoORDENADA5000) <- Nlabels
colnames(compRemocaoORDENADA5000) <- Nlabels
colnames(copiasRemocaoORDENADA5000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeRemocaoORDENADA5000.pdf")
barplot(timeRemocaoORDENADA5000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Remoção Ordenada (NInserção = 5000)")
legend(x = 1, y = 2e-1, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compRemocaoORDENADA5000.pdf")
barplot(compRemocaoORDENADA5000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Remoção Ordenada (NInserção = 5000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasRemocaoORDENADA5000.pdf")
barplot(copiasRemocaoORDENADA5000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Remoção Ordenada (NInserção = 5000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

#****************************************************************************
# Remocao
# Ninsercao = 10000

timeRemocaoAVL10000 = c(0.0015242, 0.0078518, 0.0160812, 0.0690478, 0.155228, 0.763308)
compRemocaoAVL10000 = c(20303.2, 111138, 232499, 1.1647e+06, 2.43259e+06, 1.2261e+07)
copiasRemocaoAVL10000 = c(14550, 82527.6, 175200, 877160, 1.84792e+06, 9.20094e+06)

timeRemocaoORDENADAAVL10000 = c(0.001173, 0.0054078, 0.0101064, 0.041971, 0.084726, 0.396033)
compRemocaoORDENADAAVL10000 = c(21250.2, 111407, 232756, 1.16794e+06, 2.43837e+06, 1.23504e+07)
copiasRemocaoORDENADAAVL10000 = c(15538, 82766.4, 175422, 878738, 1.85049e+06, 9.21537e+06)

timeRemocaoAVLM10000 = c(0.0015044, 0.007119, 0.0123214, 0.0521498, 0.102161, 0.495918)
compRemocaoAVLM10000 = c(21360.4, 110831, 224514, 1.12168e+06, 2.18913e+06, 1.10128e+07)
copiasRemocaoAVLM10000 = c(15326, 83401, 168425, 839565, 1.62713e+06, 8.29024e+06)

timeRemocaoORDENADAAVLM10000 = c(0.0011262, 0.00464, 0.008469, 0.0360954, 0.0693636, 0.348275)
compRemocaoORDENADAAVLM10000 = c(21829.6, 112681, 226991, 1.11241e+06, 2.18594e+06, 1.11307e+07)
copiasRemocaoORDENADAAVLM10000 = c(16130.2, 84914, 170669, 830126, 1.63756e+06, 8.35207e+06)

timeRemocaoVP10000 = c(0.0003776, 0.0019416, 0.0032748, 0.013712, 0.024666, 0.115609)
compRemocaoVP10000 = c(20369.4, 101870, 203803, 1.01744e+06, 2.03303e+06, 1.00858e+07)
copiasRemocaoVP10000 = c(2.4, 42.2, 93.8, 413.2, 837.2, 4111.2)

timeRemocaoORDENADAVP10000 = c(0.0003346, 0.0011254, 0.0017358, 0.005572, 0.0102282, 0.0479144)
compRemocaoORDENADAVP10000 = c(20354.6, 101815, 203861, 1.01743e+06, 2.03276e+06, 1.00841e+07)
copiasRemocaoORDENADAVP10000 = c(1.8, 30.8, 70.6, 278.4, 599.4, 2882.8)

timeRemocaoSplay10000 = c(0.0010734, 0.0048692, 0.0082246, 0.0377796, 0.0712312, 0.339878)
compRemocaoSplay10000 = c(53055.4, 254392, 504124, 2.49711e+06, 4.98323e+06, 2.47102e+07)
copiasRemocaoSplay10000 = c(34787.8, 165992, 328611, 1.62549e+06, 3.24259e+06, 1.60786e+07)

timeRemocaoORDENADASplay10000 = c(0.0005888, 0.0014938, 0.0018916, 0.0042466, 0.0073006, 0.031961)
compRemocaoORDENADASplay10000 = c(23522.2, 71595, 113288, 380290, 705030, 3.30264e+06)
copiasRemocaoORDENADASplay10000 = c(16355.4, 50098.6, 78358.8, 245395, 445098, 2.04296e+06)

timeRemocaoB310000 = c(0.0012508, 0.0039542, 0.0072596, 0.0251928, 0.045622, 0.226223)
compRemocaoB310000 = c(24901.6, 123424, 246968, 1.22801e+06, 2.45113e+06, 1.22518e+07)
copiasRemocaoB310000 = c(3423.4, 12082.4, 27535.8, 115411, 218984, 1.21183e+06)

timeRemocaoORDENADAB310000 = c(0.0006654, 0.0017006, 0.0026534, 0.007472, 0.0139734, 0.0649712)
compRemocaoORDENADAB310000 = c(25761, 128169, 256958, 1.28298e+06, 2.56598e+06, 1.28165e+07)
copiasRemocaoORDENADAB310000 = c(1547.6, 2986.2, 3510.8, 4329, 4710, 7373.6)

timeRemocaoB510000 = c(0.000679, 0.0023138, 0.0032086, 0.0138214, 0.0277248, 0.125337)
compRemocaoB510000 = c(24168.4, 121116, 241231, 1.19712e+06, 2.39679e+06, 1.19511e+07)
copiasRemocaoB510000 = c(1890, 5433.8, 6462.6, 37355.6, 91444.8, 430823)

timeRemocaoORDENADAB510000 = c(0.0004524, 0.0011558, 0.0017984, 0.0061786, 0.0115308, 0.054951)
compRemocaoORDENADAB510000 = c(24782.6, 123364, 247505, 1.23549e+06, 2.46842e+06, 1.22441e+07)
copiasRemocaoORDENADAB510000 = c(832.2, 1663, 1961.4, 2387.6, 2951, 7093.4)

#-----------------------------
# Graficos remocao

timeRemocao10000 <- as.matrix(data.frame(rbind(timeRemocaoAVL10000, timeRemocaoAVLM10000, 
                                              timeRemocaoVP10000, timeRemocaoSplay10000, 
                                              timeRemocaoB310000, timeRemocaoB510000)))

compRemocao10000 <- as.matrix(data.frame(rbind(compRemocaoAVL10000, compRemocaoAVLM10000, 
                                              compRemocaoVP10000, compRemocaoSplay10000, 
                                              compRemocaoB310000, compRemocaoB510000)))

copiasRemocao10000 <- as.matrix(data.frame(rbind(copiasRemocaoAVL10000, copiasRemocaoAVLM10000, 
                                                copiasRemocaoVP10000, copiasRemocaoSplay10000, 
                                                copiasRemocaoB310000, copiasRemocaoB510000)))

colnames(timeRemocao10000) <- Nlabels
colnames(compRemocao10000) <- Nlabels
colnames(copiasRemocao10000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeRemocao10000.pdf")
barplot(timeRemocao10000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Remoção (NInserção = 10000)")
legend(x = 1, y = 5e-01, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compRemocao10000.pdf")
barplot(compRemocao10000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Remoção (NInserção = 10000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasRemocao10000.pdf")
barplot(copiasRemocao10000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Remoção (NInserção = 10000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()


#-----------------------------
# Graficos remocao ordenada

timeRemocaoORDENADA10000 <- as.matrix(data.frame(rbind(timeRemocaoORDENADAAVL10000, timeRemocaoORDENADAAVLM10000, 
                                                      timeRemocaoORDENADAVP10000, timeRemocaoORDENADASplay10000, 
                                                      timeRemocaoORDENADAB310000, timeRemocaoORDENADAB510000)))

compRemocaoORDENADA10000 <- as.matrix(data.frame(rbind(compRemocaoORDENADAAVL10000, compRemocaoORDENADAAVLM10000, 
                                                      compRemocaoORDENADAVP10000, compRemocaoORDENADASplay10000, 
                                                      compRemocaoORDENADAB310000, compRemocaoORDENADAB510000)))

copiasRemocaoORDENADA10000 <- as.matrix(data.frame(rbind(copiasRemocaoORDENADAAVL10000, copiasRemocaoORDENADAAVLM10000, 
                                                        copiasRemocaoORDENADAVP10000, copiasRemocaoORDENADASplay10000, 
                                                        copiasRemocaoORDENADAB310000, copiasRemocaoORDENADAB510000)))

colnames(timeRemocaoORDENADA10000) <- Nlabels
colnames(compRemocaoORDENADA10000) <- Nlabels
colnames(copiasRemocaoORDENADA10000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeRemocaoORDENADA10000.pdf")
barplot(timeRemocaoORDENADA10000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Remoção Ordenada (NInserção = 10000)")
legend(x = 1, y = 2e-1, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compRemocaoORDENADA10000.pdf")
barplot(compRemocaoORDENADA10000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Remoção Ordenada (NInserção = 10000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasRemocaoORDENADA10000.pdf")
barplot(copiasRemocaoORDENADA10000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Remoção Ordenada (NInserção = 10000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()


#****************************************************************************
# Remocao
# Ninsercao = 50000

timeRemocaoAVL50000 = c(0.0022464, 0.0112088, 0.0253964, 0.121681, 0.273057, 1.35559)
compRemocaoAVL50000 = c(23933.2, 128954, 268227, 1.34557e+06, 2.79589e+06, 1.40737e+07)
copiasRemocaoAVL50000 = c(16951.6, 94458.6, 199170, 997497, 2.0857e+06, 1.03906e+07)

timeRemocaoORDENADAAVL50000 = c(0.0016648, 0.0077348, 0.0163204, 0.0653324, 0.126939, 0.500477)
compRemocaoORDENADAAVL50000 = c(24825.8, 129352, 268395, 1.34666e+06, 2.8005e+06, 1.41583e+07)
copiasRemocaoORDENADAAVL50000 = c(17914.6, 94683.2, 199116, 998289, 2.08782e+06, 1.04011e+07)

timeRemocaoAVLM50000 = c(0.0024172, 0.0106338, 0.019146, 0.0848594, 0.158152, 0.806391)
compRemocaoAVLM50000 = c(24995.2, 128757, 263387, 1.31073e+06, 2.57195e+06, 1.28038e+07)
copiasRemocaoAVLM50000 = c(17850.4, 95449.6, 195572, 972036, 1.89028e+06, 9.45606e+06)

timeRemocaoORDENADAAVLM50000 = c(0.001613, 0.0066534, 0.0116648, 0.0474394, 0.0883326, 0.42101)
compRemocaoORDENADAAVLM50000 = c(25440.8, 130457, 258985, 1.28831e+06, 2.56166e+06, 1.28788e+07)
copiasRemocaoORDENADAAVLM50000 = c(18663.4, 96644.8, 191665, 949785, 1.88801e+06, 9.49857e+06)

timeRemocaoVP50000 = c(0.0006192, 0.0033138, 0.0066296, 0.0289424, 0.052501, 0.239781)
compRemocaoVP50000 = c(23909.6, 119617, 239544, 1.19634e+06, 2.39084e+06, 1.18732e+07)
copiasRemocaoVP50000 = c(42.2, 202.2, 398.2, 2100, 4137.8, 20160.6)

timeRemocaoORDENADAVP50000 = c(0.0005466, 0.0019348, 0.0032868, 0.0102698, 0.0170662, 0.0627124)
compRemocaoORDENADAVP50000 = c(23894.2, 119609, 239452, 1.19627e+06, 2.39069e+06, 1.18679e+07)
copiasRemocaoORDENADAVP50000 = c(23.4, 161.8, 279.2, 1478.4, 2903, 14370.8)

timeRemocaoSplay50000 = c(0.0015074, 0.0079016, 0.0144704, 0.061852, 0.117195, 0.550752)
compRemocaoSplay50000 = c(65528.4, 312660, 614661, 2.99845e+06, 5.96431e+06, 2.95053e+07)
copiasRemocaoSplay50000 = c(43014.4, 204063, 400679, 1.94767e+06, 3.87119e+06, 1.91376e+07)

timeRemocaoORDENADASplay50000 = c(0.000956, 0.003007, 0.0047592, 0.010321, 0.0147648, 0.041464)
compRemocaoORDENADASplay50000 = c(33773.2, 118680, 194899, 566123, 916105, 3.51775e+06)
copiasRemocaoORDENADASplay50000 = c(23161.6, 82504.8, 136394, 391186, 616058, 2.22027e+06)

timeRemocaoB350000 = c(0.0021778, 0.0072208, 0.0118444, 0.0418912, 0.0717008, 0.30423)
compRemocaoB350000 = c(29242, 144689, 287937, 1.42788e+06, 2.84811e+06, 1.41681e+07)
copiasRemocaoB350000 = c(5586.6, 17039.8, 26805.4, 89979.6, 149033, 627979)

timeRemocaoORDENADAB350000 = c(0.0014836, 0.003654, 0.00546, 0.015097, 0.0240594, 0.0857202)
compRemocaoORDENADAB350000 = c(30044.6, 150812, 301464, 1.5058e+06, 3.01186e+06, 1.50524e+07)
copiasRemocaoORDENADAB350000 = c(2914.8, 7745, 10754, 18919.4, 22189.8, 35856.2)

timeRemocaoB550000 = c(0.0012186, 0.0052022, 0.0076156, 0.0280032, 0.0476822, 0.188909)
compRemocaoB550000 = c(28670.2, 142399, 284487, 1.4263e+06, 2.83178e+06, 1.40039e+07)
copiasRemocaoB550000 = c(3051.6, 13526.2, 15692, 74483.6, 99525.4, 405332)

timeRemocaoORDENADAB550000 = c(0.0008192, 0.002484, 0.0039312, 0.011919, 0.0200524, 0.073362)
compRemocaoORDENADAB550000 = c(29194.4, 145891, 291199, 1.45592e+06, 2.90889e+06, 1.44711e+07)
copiasRemocaoORDENADAB550000 = c(1752.8, 4490, 6348.4, 11917.4, 14586, 34841.4)

#-----------------------------
# Graficos remocao

timeRemocao50000 <- as.matrix(data.frame(rbind(timeRemocaoAVL50000, timeRemocaoAVLM50000, 
                                               timeRemocaoVP50000, timeRemocaoSplay50000, 
                                               timeRemocaoB350000, timeRemocaoB550000)))

compRemocao50000 <- as.matrix(data.frame(rbind(compRemocaoAVL50000, compRemocaoAVLM50000, 
                                               compRemocaoVP50000, compRemocaoSplay50000, 
                                               compRemocaoB350000, compRemocaoB550000)))

copiasRemocao50000 <- as.matrix(data.frame(rbind(copiasRemocaoAVL50000, copiasRemocaoAVLM50000, 
                                                 copiasRemocaoVP50000, copiasRemocaoSplay50000, 
                                                 copiasRemocaoB350000, copiasRemocaoB550000)))

colnames(timeRemocao50000) <- Nlabels
colnames(compRemocao50000) <- Nlabels
colnames(copiasRemocao50000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeRemocao50000.pdf")
barplot(timeRemocao50000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Remoção (NInserção = 50000)")
legend(x = 1, y = 1e00, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compRemocao50000.pdf")
barplot(compRemocao50000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Remoção (NInserção = 50000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasRemocao50000.pdf")
barplot(copiasRemocao50000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Remoção (NInserção = 50000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()


#-----------------------------
# Graficos remocao ordenada

timeRemocaoORDENADA50000 <- as.matrix(data.frame(rbind(timeRemocaoORDENADAAVL50000, timeRemocaoORDENADAAVLM50000, 
                                                       timeRemocaoORDENADAVP50000, timeRemocaoORDENADASplay50000, 
                                                       timeRemocaoORDENADAB350000, timeRemocaoORDENADAB550000)))

compRemocaoORDENADA50000 <- as.matrix(data.frame(rbind(compRemocaoORDENADAAVL50000, compRemocaoORDENADAAVLM50000, 
                                                       compRemocaoORDENADAVP50000, compRemocaoORDENADASplay50000, 
                                                       compRemocaoORDENADAB350000, compRemocaoORDENADAB550000)))

copiasRemocaoORDENADA50000 <- as.matrix(data.frame(rbind(copiasRemocaoORDENADAAVL50000, copiasRemocaoORDENADAAVLM50000, 
                                                         copiasRemocaoORDENADAVP50000, copiasRemocaoORDENADASplay50000, 
                                                         copiasRemocaoORDENADAB350000, copiasRemocaoORDENADAB550000)))

colnames(timeRemocaoORDENADA50000) <- Nlabels
colnames(compRemocaoORDENADA50000) <- Nlabels
colnames(copiasRemocaoORDENADA50000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeRemocaoORDENADA50000.pdf")
barplot(timeRemocaoORDENADA50000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Remoção Ordenada (NInserção = 50000)")
legend(x = 1, y = 5e-1, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compRemocaoORDENADA50000.pdf")
barplot(compRemocaoORDENADA50000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Remoção Ordenada (NInserção = 50000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasRemocaoORDENADA50000.pdf")
barplot(copiasRemocaoORDENADA50000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Remoção Ordenada (NInserção = 50000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()



#****************************************************************************
# Remocao
# Ninsercao = 100000

timeRemocaoAVL100000 = c(0.0023102, 0.0134448, 0.0293888, 0.146158, 0.32296, 1.62059)
compRemocaoAVL100000 = c(25434.4, 136749, 283865, 1.42501e+06, 2.95097e+06, 1.48467e+07)
copiasRemocaoAVL100000 = c(17937.2, 99585.4, 209717, 1.04994e+06, 2.18971e+06, 1.09115e+07)

timeRemocaoORDENADAAVL100000 = c(0.0018678, 0.0093518, 0.0199108, 0.0831748, 0.164935, 0.56776)
compRemocaoORDENADAAVL100000 = c(26316.2, 137213, 283967, 1.42655e+06, 2.95529e+06, 1.49246e+07)
copiasRemocaoORDENADAAVL100000 = c(18893.6, 99797.6, 209331, 1.0499e+06, 2.1905e+06, 1.09177e+07)

timeRemocaoAVLM100000 = c(0.0026174, 0.0124518, 0.0236268, 0.111196, 0.214539, 1.12127)
compRemocaoAVLM100000 = c(26475.4, 136996, 278490, 1.38331e+06, 2.69161e+06, 1.36329e+07)
copiasRemocaoAVLM100000 = c(18851.2, 101057, 206023, 1.01842e+06, 1.95402e+06, 1.0008e+07)

timeRemocaoORDENADAAVLM100000 = c(0.00187, 0.0079212, 0.0141704, 0.054648, 0.10121, 0.466225)
compRemocaoORDENADAAVLM100000 = c(26783, 138336, 277640, 1.37252e+06, 2.69958e+06, 1.37836e+07)
copiasRemocaoORDENADAAVLM100000 = c(19525.8, 102148, 204636, 1.00324e+06, 1.98161e+06, 1.0193e+07)

timeRemocaoVP100000 = c(0.0007888, 0.004284, 0.0082258, 0.036702, 0.0727346, 0.354009)
compRemocaoVP100000 = c(25399.2, 127285, 254173, 1.27011e+06, 2.53808e+06, 1.26097e+07)
copiasRemocaoVP100000 = c(92, 436.2, 893.2, 4386, 8500, 40130.2)

timeRemocaoORDENADAVP100000 = c(0.0006838, 0.0025352, 0.0044052, 0.0144406, 0.0235972, 0.0769196)
compRemocaoORDENADAVP100000 = c(25352, 127323, 254129, 1.26956e+06, 2.5373e+06, 1.26013e+07)
copiasRemocaoORDENADAVP100000 = c(70.2, 289.6, 613.4, 3070.6, 5957.4, 28592.4)

timeRemocaoSplay100000 = c(0.0019228, 0.0095608, 0.0180432, 0.0807392, 0.15347, 0.734441)
compRemocaoSplay100000 = c(71156.2, 339686, 668849, 3.24379e+06, 6.43429e+06, 3.17264e+07)
copiasRemocaoSplay100000 = c(46646.4, 221624, 435519, 2.10476e+06, 4.17014e+06, 2.05409e+07)

timeRemocaoORDENADASplay100000 = c(0.0011728, 0.0039472, 0.0063434, 0.0160444, 0.0228242, 0.0533784)
compRemocaoORDENADASplay100000 = c(38281.6, 140054, 236955, 718948, 1.12984e+06, 3.7854e+06)
copiasRemocaoORDENADASplay100000 = c(26082.2, 96667.4, 164655, 503278, 780608, 2.44146e+06)

timeRemocaoB3100000 = c(0.0023498, 0.0095076, 0.0164734, 0.057447, 0.106832, 0.464786)
compRemocaoB3100000 = c(30582.8, 151147, 301838, 1.48368e+06, 2.95961e+06, 1.46846e+07)
copiasRemocaoB3100000 = c(6002.2, 20784.8, 37057.8, 106447, 203150, 787137)

timeRemocaoORDENADAB3100000 = c(0.001554, 0.0048866, 0.0077188, 0.0215696, 0.034627, 0.103318)
compRemocaoORDENADAB3100000 = c(32759.4, 164734, 328478, 1.64184e+06, 3.28143e+06, 1.6397e+07)
copiasRemocaoORDENADAB3100000 = c(3612.2, 10552.8, 15573.4, 31875.2, 40269.6, 70505.8)

timeRemocaoB5100000 = c(0.001692, 0.0058412, 0.0097526, 0.0353882, 0.061894, 0.272554)
compRemocaoB5100000 = c(30583, 152541, 303878, 1.51122e+06, 3.00912e+06, 1.49749e+07)
copiasRemocaoB5100000 = c(3820.4, 12275, 18557.2, 70764.6, 100155, 513290)

timeRemocaoORDENADAB5100000 = c(0.0010736, 0.003369, 0.0054616, 0.016289, 0.0265718, 0.0923936)
compRemocaoORDENADAB5100000 = c(31232, 155838, 311532, 1.55447e+06, 3.11003e+06, 1.54705e+07)
copiasRemocaoORDENADAB5100000 = c(2312.4, 6428.8, 9496.2, 20601.2, 27864.4, 68487.2)

#-----------------------------
# Graficos remocao

timeRemocao100000 <- as.matrix(data.frame(rbind(timeRemocaoAVL100000, timeRemocaoAVLM100000, 
                                               timeRemocaoVP100000, timeRemocaoSplay100000, 
                                               timeRemocaoB3100000, timeRemocaoB5100000)))

compRemocao100000 <- as.matrix(data.frame(rbind(compRemocaoAVL100000, compRemocaoAVLM100000, 
                                               compRemocaoVP100000, compRemocaoSplay100000, 
                                               compRemocaoB3100000, compRemocaoB5100000)))

copiasRemocao100000 <- as.matrix(data.frame(rbind(copiasRemocaoAVL100000, copiasRemocaoAVLM100000, 
                                                 copiasRemocaoVP100000, copiasRemocaoSplay100000, 
                                                 copiasRemocaoB3100000, copiasRemocaoB5100000)))

colnames(timeRemocao100000) <- Nlabels
colnames(compRemocao100000) <- Nlabels
colnames(copiasRemocao100000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeRemocao100000.pdf")
barplot(timeRemocao100000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Remoção (NInserção = 100000)")
legend(x = 1, y = 1e00, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compRemocao100000.pdf")
barplot(compRemocao100000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Remoção (NInserção = 100000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasRemocao100000.pdf")
barplot(copiasRemocao100000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Remoção (NInserção = 100000)")
legend(x = 1, y = 4e06, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()


#-----------------------------
# Graficos remocao ordenada

timeRemocaoORDENADA100000 <- as.matrix(data.frame(rbind(timeRemocaoORDENADAAVL100000, timeRemocaoORDENADAAVLM100000, 
                                                       timeRemocaoORDENADAVP100000, timeRemocaoORDENADASplay100000, 
                                                       timeRemocaoORDENADAB3100000, timeRemocaoORDENADAB5100000)))

compRemocaoORDENADA100000 <- as.matrix(data.frame(rbind(compRemocaoORDENADAAVL100000, compRemocaoORDENADAAVLM100000, 
                                                       compRemocaoORDENADAVP100000, compRemocaoORDENADASplay100000, 
                                                       compRemocaoORDENADAB3100000, compRemocaoORDENADAB5100000)))

copiasRemocaoORDENADA100000 <- as.matrix(data.frame(rbind(copiasRemocaoORDENADAAVL100000, copiasRemocaoORDENADAAVLM100000, 
                                                         copiasRemocaoORDENADAVP100000, copiasRemocaoORDENADASplay100000, 
                                                         copiasRemocaoORDENADAB3100000, copiasRemocaoORDENADAB5100000)))

colnames(timeRemocaoORDENADA100000) <- Nlabels
colnames(compRemocaoORDENADA100000) <- Nlabels
colnames(copiasRemocaoORDENADA100000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeRemocaoORDENADA100000.pdf")
barplot(timeRemocaoORDENADA100000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Remoção Ordenada (NInserção = 100000)")
legend(x = 1, y = 4e-01, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compRemocaoORDENADA100000.pdf")
barplot(compRemocaoORDENADA100000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Remoção Ordenada (NInserção = 100000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasRemocaoORDENADA100000.pdf")
barplot(copiasRemocaoORDENADA100000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Remoção Ordenada (NInserção = 100000)")
legend(x = 1, y = 5e06, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()


#****************************************************************************
# Remocao
# Ninsercao = 500000

timeRemocaoAVL500000 = c(0.0019148, 0.011567, 0.0260216, 0.130545, 0.285635, 1.43382)
compRemocaoAVL500000 = c(17452, 92785.6, 192419, 972026, 1.99654e+06, 1.00306e+07)
copiasRemocaoAVL500000 = c(12230.6, 67177.8, 141837, 709762, 1.4659e+06, 7.31441e+06)

timeRemocaoORDENADAAVL500000 = c(0.0016428, 0.0084658, 0.0174026, 0.078107, 0.16045, 0.642631)
compRemocaoORDENADAAVL500000 = c(17975.2, 93522, 192210, 969757, 1.99636e+06, 1.00607e+07)
copiasRemocaoORDENADAAVL500000 = c(12783, 67194.8, 140286, 706158, 1.46207e+06, 7.30539e+06)

timeRemocaoAVLM500000 = c(0.0018534, 0.010929, 0.0212714, 0.0993888, 0.207271, 1.02476)
compRemocaoAVLM500000 = c(18114.2, 92663.4, 187049, 935189, 1.84952e+06, 9.38539e+06)
copiasRemocaoAVLM500000 = c(12771.4, 67403.2, 136318, 680120, 1.34785e+06, 6.85907e+06)

timeRemocaoORDENADAAVLM500000 = c(0.0016646, 0.0071, 0.0137018, 0.051418, 0.0945352, 0.361849)
compRemocaoORDENADAAVLM500000 = c(18464.4, 93448, 187655, 921342, 1.86071e+06, 9.19131e+06)
copiasRemocaoORDENADAAVLM500000 = c(13484.8, 68210, 136814, 665896, 1.35025e+06, 6.66178e+06)

timeRemocaoVP500000 = c(0.0007372, 0.004045, 0.0108376, 0.0360616, 0.0731056, 0.359311)
compRemocaoVP500000 = c(17345.4, 86642.4, 173104, 865839, 1.73054e+06, 8.60189e+06)
copiasRemocaoVP500000 = c(232.6, 1162, 2331.6, 11818.2, 23778.8, 113325)

timeRemocaoORDENADAVP500000 = c(0.0006484, 0.0025102, 0.0045582, 0.0160528, 0.0279108, 0.089577)
compRemocaoORDENADAVP500000 = c(17290.2, 86627.8, 172817, 864767, 1.72861e+06, 8.59058e+06)
copiasRemocaoORDENADAVP500000 = c(158.8, 816.4, 1644.2, 8280.6, 16684, 80995.6)

timeRemocaoSplay500000 = c(0.0016898, 0.0084458, 0.0157934, 0.073336, 0.143886, 0.694027)
compRemocaoSplay500000 = c(51681.4, 249706, 491239, 2.38078e+06, 4.70499e+06, 2.29148e+07)
copiasRemocaoSplay500000 = c(33590, 161617, 317587, 1.53201e+06, 3.02333e+06, 1.47001e+07)

timeRemocaoORDENADASplay500000 = c(0.0011792, 0.0043728, 0.0074148, 0.0222648, 0.034073, 0.0796762)
compRemocaoORDENADASplay500000 = c(29512.6, 115846, 204570, 710693, 1.16448e+06, 3.33021e+06)
copiasRemocaoORDENADASplay500000 = c(19761, 78338.4, 139241, 492005, 812029, 2.29875e+06)

timeRemocaoB3500000 = c(0.002595, 0.0099492, 0.017504, 0.0651438, 0.11575, 0.489384)
compRemocaoB3500000 = c(21785, 106068, 210298, 1.02678e+06, 2.03539e+06, 1.00592e+07)
copiasRemocaoB3500000 = c(5497.6, 21173.8, 36597.8, 116751, 190048, 715177)

timeRemocaoORDENADAB3500000 = c(0.0015862, 0.0055254, 0.0094608, 0.0289546, 0.0441902, 0.125873)
compRemocaoORDENADAB3500000 = c(22864.8, 113873, 228190, 1.13535e+06, 2.27052e+06, 1.13849e+07)
copiasRemocaoORDENADAB3500000 = c(3296.8, 11251, 18423, 51497.8, 76347.6, 182383)

timeRemocaoB5500000 = c(0.0014736, 0.0060484, 0.010317, 0.0406578, 0.0717444, 0.326346)
compRemocaoB5500000 = c(21003.6, 103767, 208801, 1.03601e+06, 2.06568e+06, 1.02216e+07)
copiasRemocaoB5500000 = c(3498.2, 11885.8, 20690.4, 74545.2, 131929, 593697)

timeRemocaoORDENADAB5500000 = c(0.0011136, 0.003692, 0.0062786, 0.0195486, 0.032114, 0.1037)
compRemocaoORDENADAB5500000 = c(21487.2, 107664, 214892, 1.07377e+06, 2.14731e+06, 1.06962e+07)
copiasRemocaoORDENADAB5500000 = c(2273.4, 7590.4, 12357.6, 37193.6, 58911.8, 187869)

#-----------------------------
# Graficos remocao

timeRemocao500000 <- as.matrix(data.frame(rbind(timeRemocaoAVL500000, timeRemocaoAVLM500000, 
                                               timeRemocaoVP500000, timeRemocaoSplay500000, 
                                               timeRemocaoB3500000, timeRemocaoB5500000)))

compRemocao500000 <- as.matrix(data.frame(rbind(compRemocaoAVL500000, compRemocaoAVLM500000, 
                                               compRemocaoVP500000, compRemocaoSplay500000, 
                                               compRemocaoB3500000, compRemocaoB5500000)))

copiasRemocao500000 <- as.matrix(data.frame(rbind(copiasRemocaoAVL500000, copiasRemocaoAVLM500000, 
                                                 copiasRemocaoVP500000, copiasRemocaoSplay500000, 
                                                 copiasRemocaoB3500000, copiasRemocaoB5500000)))

colnames(timeRemocao500000) <- Nlabels
colnames(compRemocao500000) <- Nlabels
colnames(copiasRemocao500000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeRemocao500000.pdf")
barplot(timeRemocao500000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Remoção (NInserção = 500000)")
legend(x = 1, y = 1e00, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compRemocao500000.pdf")
barplot(compRemocao500000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Remoção (NInserção = 500000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasRemocao500000.pdf")
barplot(copiasRemocao500000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Remoção (NInserção = 500000)")
legend(x = 1, y = 2e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()


#-----------------------------
# Graficos remocao ordenada

timeRemocaoORDENADA500000 <- as.matrix(data.frame(rbind(timeRemocaoORDENADAAVL500000, timeRemocaoORDENADAAVLM500000, 
                                                       timeRemocaoORDENADAVP500000, timeRemocaoORDENADASplay500000, 
                                                       timeRemocaoORDENADAB3500000, timeRemocaoORDENADAB5500000)))

compRemocaoORDENADA500000 <- as.matrix(data.frame(rbind(compRemocaoORDENADAAVL500000, compRemocaoORDENADAAVLM500000, 
                                                       compRemocaoORDENADAVP500000, compRemocaoORDENADASplay500000, 
                                                       compRemocaoORDENADAB3500000, compRemocaoORDENADAB5500000)))

copiasRemocaoORDENADA500000 <- as.matrix(data.frame(rbind(copiasRemocaoORDENADAAVL500000, copiasRemocaoORDENADAAVLM500000, 
                                                         copiasRemocaoORDENADAVP500000, copiasRemocaoORDENADASplay500000, 
                                                         copiasRemocaoORDENADAB3500000, copiasRemocaoORDENADAB5500000)))

colnames(timeRemocaoORDENADA500000) <- Nlabels
colnames(compRemocaoORDENADA500000) <- Nlabels
colnames(copiasRemocaoORDENADA500000) <- Nlabels

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/timeRemocaoORDENADA500000.pdf")
barplot(timeRemocaoORDENADA500000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Tempo Médio de CPU (segundos)", log = "y", main = "Remoção Ordenada (NInserção = 500000)")
legend(x = 1, y = 8e-1, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/compRemocaoORDENADA500000.pdf")
barplot(compRemocaoORDENADA500000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Comparações", log = "y", main = "Remoção Ordenada (NInserção = 500000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

pdf("/home/josecarvalho/Documents/PROG/CodeBlocks/Trabalho_2_EDII_2018_3/Graficos PDF/copiasRemocaoORDENADA500000.pdf")
barplot(copiasRemocaoORDENADA500000, col=c("red", "blue", "purple", "green", "black", "yellow"), 
        border="white", font.axis=2, beside=T, xlab="NRemocao", font.lab=2,
        ylab = "Número Médio de Cópias", log = "y", main = "Remoção Ordenada (NInserção = 500000)")
legend(x = 1, y = 1e07, legend = tree_names,
       fill = c("red", "blue", "purple", "green", "black", "yellow"), bty = "n")
dev.off()

